criaCartao(
    'Programação',
    'O que é Python?',
    'O Python é uma linguagem de programação'
)

criaCartao(
    'Vingadores',
    'Qual o primeiro vingador?',
    'O Capitão America'
)

criaCartao(
    'Conhecimento geral',
    'Qual o orgão responsavel por bombear sangue?',
    'O coração'
)

criaCartao(
    'alanzoka',
    'Oque a abelha come?',
    'A Florrrr'
)